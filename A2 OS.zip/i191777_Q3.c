#include<iostream>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>
#include<cstring>
#include<fcntl.h>
using namespace std;

int main()
{
start:
int fd1[2];
pipe(fd1);
int fd2[2];
pipe(fd2);
int fd3[2];
pipe(fd3);
int fd4[2];
pipe(fd4);
int fd5[2];
pipe(fd5);
int fd6[2];
pipe(fd6);
int fd7[2];
pipe(fd7);
int fd8[2];
pipe(fd8);
int fd9[2];
pipe(fd9);
int fd0[2];
pipe(fd0);


char a[3];
int hour,min;



int yes=0;
cout<<"Enter Time to ask the employees if they are free?\nHOUR::";
cin>>hour;
cout<<"MINUITE::";
cin>>min;
cout<<"AM or PM:::";
cin>>a;


pid_t pid1;
pid1=fork();
if(pid1<0)
perror("fork error");



	if(pid1==0)
	{
	char string1[100];
	close(fd1[0]);
        cout<<"Employee no.1 are you free at::("<<hour<<":"<<min<<")::(yes or no)?";
        cin>>string1;
        write(fd1[1],string1, sizeof(string1));
        close(fd1[1]);
	//c1
	}
	else
	{
	char readbuffer1[100];
	wait(NULL);
	close(fd1[1]);
	read(fd1[0], readbuffer1, sizeof(readbuffer1));
	if(strcmp(readbuffer1, "yes") == 0)
	{
	++yes;
	}
	close(fd1[0]);
	
	
	pid_t pid2=fork();
		if(pid2<0)
		perror("fork2 error");
		 if(pid2==0)
		{
		//c2
		char string2[100];
		close(fd2[0]);
        	cout<<"Employee no.2 are you free at::("<<hour<<":"<<min<<")::(yes or no)?";
        	cin>>string2;
        	write(fd2[1],string2, sizeof(string2));
        	close(fd2[1]);
		}
		 else
		{
		char readbuffer2[100];
		wait(NULL);
		close(fd2[1]);
		read(fd2[0], readbuffer2, sizeof(readbuffer2));
		if(strcmp(readbuffer2, "yes") == 0)
		{
		++yes;
		}
		close(fd2[0]);
  		pid_t pid3=fork();
  		
  		
			if(pid3<0)
			perror("fork error");
			if(pid3==0)
			{
			//c3
			char string3[100];
			close(fd3[0]);
			cout<<"Employee no.3 are you free at::("<<hour<<":"<<min<<")::(yes or no)?";
			cin>>string3;
			write(fd3[1],string3, sizeof(string3));
			close(fd3[1]);
			}
			else{

			char readbuffer3[100];
			wait(NULL);
			close(fd3[1]);
			read(fd3[0], readbuffer3, sizeof(readbuffer3));
			if(strcmp(readbuffer3, "yes") == 0)
			{
			++yes;
			}
			close(fd3[0]);
			pid_t pid4=fork();
				if(pid4<0)
				perror("fork error");



				if(pid4==0)
				{
				//c4
				char string4[100];
				close(fd4[0]);
				cout<<"Employee no.4 are you free at::("<<hour<<":"<<min<<")::(yes or no)?";
				cin>>string4;
				write(fd4[1],string4, sizeof(string4));
				close(fd4[1]);
				}
				else
				{
				
				//Parent
				char readbuffer4[100];
					wait(NULL);
					close(fd4[1]);
					read(fd4[0], readbuffer4, sizeof(readbuffer4));
					if(strcmp(readbuffer4, "yes") == 0)
					{
					++yes;
					}
					close(fd4[0]);
					pid_t pid5=fork();
					if(pid5<0)
					perror("fork error");



						if(pid5==0)
						{
						//c5
						char string5[100];
						close(fd5[0]);
						cout<<"Employee no.5 are you free at::("<<hour<<":"<<min<<")::(yes or no)?";
						cin>>string5;
						write(fd5[1],string5, sizeof(string5));
						close(fd5[1]);
						}
						
						else
						{
						char readbuffer5[100];
						//Parent
						wait(NULL);
						close(fd5[1]);
						read(fd5[0], readbuffer5, sizeof(readbuffer5));
						if(strcmp(readbuffer5, "yes") == 0)
						{
						++yes;
						}
						close(fd5[0]);
						
pid_t pid6=fork();
if(pid6<0)
perror("fork error");



	if(pid6==0)
	{
	char string6[100];
	 close(fd6[0]);
        cout<<"Employee no.6 are you free at::("<<hour<<":"<<min<<")::(yes or no)?";
        cin>>string6;
        write(fd6[1],string6, sizeof(string6));
        close(fd6[1]);
	//c1
	}
	else
	{
	char readbuffer6[100];
	wait(NULL);
	close(fd6[1]);
	read(fd6[0], readbuffer6, sizeof(readbuffer6));

	if(strcmp(readbuffer6, "yes") == 0)
	{
	++yes;
	}
	close(fd6[0]);
	
	
	pid_t pid7=fork();
		if(pid7<0)
		perror("fork7 error");
		 if(pid7==0)
		{
		//c2
		char string7[100];
		close(fd7[0]);
        	cout<<"Employee no.7 are you free at::("<<hour<<":"<<min<<")::(yes or no)?";
        	cin>>string7;
        	write(fd7[1],string7, sizeof(string7));
        	close(fd7[1]);
		}
		 else
		{
		char readbuffer7[100];
		wait(NULL);
		close(fd7[1]);
		read(fd7[0], readbuffer7, sizeof(readbuffer7));

		if(strcmp(readbuffer7, "yes") == 0)
		{
		++yes;
		}
		close(fd7[0]);
  		pid_t pid8=fork();
  		
  		
			if(pid8<0)
			perror("fork error");
			if(pid8==0)
			{
			//c3
			char string8[100];
			close(fd8[0]);
			cout<<"Employee no.8 are you free at::("<<hour<<":"<<min<<")::(yes or no)?";
			cin>>string8;
			write(fd8[1],string8, sizeof(string8));
			close(fd8[1]);
			}
			else{

			char readbuffer8[100];
			wait(NULL);
			close(fd8[1]);
			read(fd8[0], readbuffer8, sizeof(readbuffer8));
			
			if(strcmp(readbuffer8, "yes") == 0)
			{
			++yes;
			}
			close(fd8[0]);
			pid_t pid9=fork();
				if(pid9<0)
				perror("fork error");



				if(pid9==0)
				{
				//c9
				char string9[100];
				close(fd9[0]);
				cout<<"Employee no.9 are you free at::("<<hour<<":"<<min<<")::(yes or no)?";
				cin>>string9;
				write(fd9[1],string9, sizeof(string9));
				close(fd9[1]);
				}
				else
				{
				
				//Parent
				char readbuffer9[100];
					wait(NULL);
					close(fd9[1]);
					read(fd9[0], readbuffer9, sizeof(readbuffer9));
					if(strcmp(readbuffer9, "yes") == 0)
					{
					++yes;
					}
					close(fd9[0]);
					pid_t pid0=fork();
					if(pid0<0)
					perror("fork error");



						if(pid0==0)
						{
						//c0
						char string0[100];
						close(fd0[0]);
						cout<<"Employee no.10 are you free at::(("<<hour<<":"<<min<<"))::(yes or no)?";
						cin>>string0;
						write(fd0[1],string0, sizeof(string0));
						close(fd0[1]);
						}
						
						else
						{
						char readbuffer0[100];
						//Parent
						wait(NULL);
						close(fd0[1]);
						read(fd0[0], readbuffer0, sizeof(readbuffer0));
						if(strcmp(readbuffer0, "yes") == 0)
						{
						++yes;
						}
						close(fd0[0]);
						cout<<endl<<"NO. of Yes"<<yes<<endl;
						if(yes!=10)
						{
						cout<<"Please set another time as all the employees are not free."<<endl;
						goto start;
						}
						else if (yes==10)
						{
						cout<<"The time has been set to("<<hour<<":"<<min<<") "<<a <<endl;
						goto end;
						}
				
				}
}

}
}
}
 
				
				}
}
}
}

}

end:
cout<<"end";
}





 
