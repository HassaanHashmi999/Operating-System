#include<iostream>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>
#include<cstring>
#include<fcntl.h>
using namespace std;
int main () {
int saved_stdout;


saved_stdout = dup(1);
int saved_stdin;


saved_stdin = dup(0);





int i=1;
while(i==1){
int fd[2];
pipe(fd);
int fd5[2];
pipe(fd5);
//parent	//read [5][0] write[0][1]
pid_t c1;	//read [0][0] write[1][1]
pid_t c2;	//read [1][0] write[2][1]	
pid_t c3;	//read [2][0] write[3][1]
pid_t c4;	//read [3][0] write[4][1]
pid_t c5;	//read [4][0] write[5][1]

	char str[100];
	
	
start:
	cout<<"Enter the string:";
	cin>>str;
  if(strcmp(str, "quit") == 0)
  {

  goto check;
  }
   c1=fork();
   
	
	
	if(c1==0){
	
	
	int fd1[2];
	pipe(fd1);
	
	
	//child1 process
	
	//now create c2
	c2=fork();
	
		if(c2==0){
		int fd2[2];
	pipe(fd2);
		//child2 process
		c3=fork();
	
			if(c3==0){
			int fd3[2];
	pipe(fd3);
			//child3 process
			c4=fork();
				if(c4==0){
				
				int fd4[2];
	pipe(fd4);
				
				//child4 process
				c5=fork();
				
				
					if(c5==0){
					char read5[100];
	
	dup2(fd4[0],STDIN_FILENO);
	close(fd4[0]);
	close(fd4[1]);
	cin>>read5;
dup2(1,STDOUT_FILENO);
	cout<<read5<<":"<<getpid()<<endl;
					//child5 process
	
	dup2(fd5[1],STDOUT_FILENO);
	cout<<read5<<":"<<getpid();
	close(fd5[0]);
	close(fd5[1]);
	dup2(1,STDOUT_FILENO);
	
	
	cout<<endl;
					}
					else
					{
					char read4[100];
	
	dup2(fd3[0],STDIN_FILENO);
	close(fd3[0]);
	close(fd3[1]);
	cin>>read4;
	dup2(1,STDOUT_FILENO);
	cout<<read4<<":"<<getpid()<<endl;
	
	
	dup2(fd4[1],STDOUT_FILENO);
	cout<<read4<<":"<<getpid();
	close(fd4[0]);
	close(fd4[1]);
	dup2(1,STDOUT_FILENO);
	
	
	cout<<endl;
	wait(NULL);
	
	
					//c4
					}
					
					
				}
				else
				{
	char read3[100];
	dup2(fd2[0],STDIN_FILENO);
	close(fd2[0]);
	close(fd2[1]);
	cin>>read3;
dup2(1,STDOUT_FILENO);
	cout<<read3<<":"<<getpid()<<endl;
	
	
	dup2(fd3[1],STDOUT_FILENO);
	cout<<read3<<":"<<getpid();
	close(fd3[0]);
	close(fd3[1]);
	dup2(1,STDOUT_FILENO);
	
	
	cout<<endl;
		
	wait(NULL);
	
	
				//c3
				}
			}
			else
			{
			char read2[100];
	
	dup2(fd1[0],STDIN_FILENO);
	close(fd1[0]);
	close(fd1[1]);
	cin>>read2;
	dup2(1,STDOUT_FILENO);
	cout<<read2<<":"<<getpid()<<endl;
	//writing
	dup2(fd2[1],STDOUT_FILENO);
	cout<<read2<<":"<<getpid();
	close(fd2[0]);
	close(fd2[1]);
	dup2(1,STDOUT_FILENO);
	
	
	cout<<endl;
		
	wait(NULL);
	
			//c2
			}
		}
		else
		{
		
		
	char read1[100];
	
	dup2(fd[0],STDIN_FILENO);
	close(fd[0]);
	close(fd[1]);
	cin>>read1;

	cout<<read1<<":"<<getpid()<<endl;
	dup2(0,STDIN_FILENO);
	///writing
	dup2(fd1[1],STDOUT_FILENO);
	cout<<read1<<":"<<getpid();
	close(fd1[0]);
	close(fd1[1]);
	dup2(1,STDOUT_FILENO);
	
	
	cout<<endl;
		//c1
	wait(NULL);
	
		}
	}
	else
	{
	
	
	
	cout<<str<<":"<<getpid()<<endl;
	
	
	
	dup2(fd[1],STDOUT_FILENO);
	cout<<str<<":"<<getpid();
	close(fd[0]);
	close(fd[1]);
	dup2(1,STDOUT_FILENO);
	
	
	cout<<endl;
	
	wait(NULL);
	
	char mainp[100];
	
	dup2(fd5[0],STDIN_FILENO);
	close(fd5[0]);
	close(fd5[1]);
	cin>>mainp;
	dup2(1,STDOUT_FILENO);
	cout<<mainp<<":"<<getpid()<<endl;
	
	
	
	
	}
check:
if(strcmp(str, "quit") == 0)
  {

  i=0;
  }
  cout<<i<<endl;
dup2(saved_stdin, 0);
dup2(saved_stdout, 1);

}
close(saved_stdin);
close(saved_stdout);

return 0 ;
}
