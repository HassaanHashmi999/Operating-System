#include<iostream>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>
#include<fcntl.h>
using namespace std;

int main()
{

int fd[2];
pipe(fd);
int fd1[2];
pipe(fd1);
int fd2[2];
pipe(fd2);


pid_t pid1;
pid1=fork();
if(pid1<0)
perror("fork error");
if(pid1==0)
{
//c1
dup2(fd[1],1);
close(fd[0]);
close(fd[1]);
execl("/bin/ls","ls","-l",NULL);
perror("An Error executing ls");
}
else
{
wait(NULL);
pid_t pid2=fork();
if(pid2<0)
perror("fork2 error");
if(pid2==0)
{
dup2(fd[0],0);
dup2(fd1[1],1);
close(fd1[0]);
close(fd1[1]);
close(fd[0]);
close(fd[1]);
execlp("grep","grep","a",NULL);
perror("An Error executing grep");
}
else
{
close(fd[1]);
close(fd[0]);
wait(NULL);
pid_t pid3=fork();
if(pid3<0)
perror("fork error");
if(pid3==0)
{
dup2(fd2[1],1);
dup2(fd1[0],0);
close(fd1[0]);
close(fd1[1]);
close(fd2[0]);
close(fd2[1]);
execlp("sort","sort","-r",NULL);
perror("An Error executing sort");
}
else{
close(fd1[0]);
close(fd1[1]);

wait(NULL);
pid_t pid4=fork();
if(pid4<0)
perror("fork error");
if(pid4==0)
{
dup2(fd2[0],0);
close(fd2[0]);
close(fd2[1]);
int file=open("a.txt",O_WRONLY);
dup2(file,1);
execlp("wc","wc",NULL);
perror("An Error executing wc");

}
else{
close(fd2[0]);
close(fd2[1]);
wait(NULL);
}

}




}
}
}
 
