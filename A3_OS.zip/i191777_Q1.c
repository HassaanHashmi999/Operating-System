#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include<iostream>
using namespace std;
int n;
float sum;
float tax;
float disc;
int multi=1;
char **items;
int *prices;
int *sums;
int *quantity;
void *create(void *arg);
void *bb_sort(void *arg);
void *calctax(void *arg);
void *calcdisc(void *arg);
void show();
void show2();
void *calcsum(void *arg);
void bubbleSort(int n)
{
    int i, j;
    for (i = 0; i < n - 1; i++)
 {
        // Last i elements are already in place
        for (j = 0; j < n - i - 1; j++){
            if (prices[j] > prices[j + 1]){
                swap(prices[j], prices[j + 1]);
                swap(items[j], items[j + 1]);
                }
                	}
                }
}
int main(){

	
	printf("\n"); 
  	pthread_t thread1;
  	pthread_t thread2;
	pthread_t thread3;
	pthread_t thread4;
	pthread_t thread5;
	
	
	cout<<"Enter the no. of items purchased::";
	cin>>n;
	prices = new int(n);	
	

	items = new char *[n];
	int i;
	for (i=0; i < n; i++)
		items[i] = new char [10];
	quantity = new int(n);
	sums = new int(n);
  pthread_create(&thread1, NULL, create, (void*)prices);
  pthread_join(thread1, NULL);
  
  pthread_create(&thread2, NULL, calcsum, (void*)sums);

  pthread_join(thread2, NULL);
  printf("By The Total is= %f \n",sum);
  
  pthread_create(&thread3, NULL, calctax, &sum);

  pthread_join(thread3, NULL);
  cout<<"The total value with Tax is::"<<tax<<endl;
  
  pthread_create(&thread4, NULL, calcdisc, &sum);

  pthread_join(thread4, NULL);
  if(sum>250)
  cout<<"The Discount(sale) is::"<<disc<<endl;
 
  pthread_create(&thread5, NULL, bb_sort, (void*)prices);
  pthread_join(thread5, NULL);

printf("\n\t\tThe Items & Prices After Sorting are:: \n\n"); 
  show();

}
void *bb_sort(void *arg)
{

int low=0;
int high=n-1;

 bubbleSort( n);
  pthread_exit(0);
}


void *create(void *arg){
for (int i=0;i<n;i++)
{
cout<<"Enter the Item:";
cin>>items[i];
cout<<"Enter the Price:";
cin>>prices[i];
cout<<"Enter the quantity:";
cin>>quantity[i];
sums[i]=prices[i]*quantity[i];

cout<<endl<<endl;
}
printf("\n\n\t\tGENERATING RESULT\n\n"); 

printf("\n"); 
pthread_exit(0);
}

void *calcsum(void *arg){
show2();
  int *val_p = (int *) arg;

  int i = 0;
  for( i = 0; i < n; i++){
    sum += val_p[i];
  }
 
  pthread_exit(0);
  
}
void *calcdisc(void *arg){
  float val_d = *(float *) arg;

  int i = 0;
  if(val_d>250)
  {
  disc=val_d*0.1;
  }
 
  pthread_exit(0);
  
}
void *calctax(void *arg){
  float val =  *(float*) arg;

  tax=val*0.08;
  cout<<"The TAX is:"<<tax<<endl;
 tax=tax+val;	
 
 
  pthread_exit(0);
  
}
void show2()
{
cout<<"Quantity *  The Price of the individual  " <<endl;
 for (int i=0;i<n;i++)
{
 
 cout<<quantity[i]<<"*"<<prices[i]<<"="<<sums[i]<<endl;
}
printf("\n");

}

void show()
{

 for (int i=0;i<n;i++)
{
  cout<<items[i]<<"\t"<<prices[i]<<endl;  
}
printf("\n");

}
