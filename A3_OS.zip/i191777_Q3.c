#include <pthread.h>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
#include <stdio.h>
#include <sys/wait.h>
#include <stdlib.h>
#include<iostream>
#include <math.h>
using namespace std;

struct task {
int id;
int task_value;
int arrival_time;
int unit_count;
int *unitIdList;
}
