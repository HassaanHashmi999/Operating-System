#include <pthread.h>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
#include <stdio.h>
#include <sys/wait.h>
#include <stdlib.h>
#include<iostream>
#include <math.h>
using namespace std;
int n;
int matrix[3][4];
int matx[4][1];
int res[3][1];
int matb[3][1];
int matadd[3][1];
int result[3][1];
void* multi(void* arg)
{
   
   int i=*(int *)arg;
   --i;

    for (int j = 0; j < 1; j++){
      for (int k = 0; k < 4; k++)
        {
        
        res[i][j] += matrix[i][k] * matx[k][j];
        
        }
        }
          pthread_exit(0);
}
void* addi(void* arg)
{
   
   int i=*(int *)arg;
   --i;

matadd[i][0]=matb[i][0]+res[i][0];
    
          pthread_exit(0);
}
void* sig(void* arg)
{
   
   int i=*(int *)arg;
   --i;

 result[3][0] = 1 / (1 + exp(-matadd[i][0]));
    
          pthread_exit(0);
}
int main(){

pid_t p1;
pid_t p2;
pid_t p3;

p3= fork();
if(p3==0)
{
		int fd1[2];
 		 pipe(fd1);

	p2=fork();
	if(p2==0)
	{ 	int fd[2];
 		 pipe(fd);
		p1=fork();	
		if(p1==0)
		{
		srand(time(0));
		for (int i = 0; i < 3; i++) {
        	for (int j = 0; j < 4; j++) {
        	
           			 matrix[i][j] = rand() % 10;
         
        	}
   		}
   		for (int i = 0; i < 4; i++) {
        	for (int j = 0; j < 1; j++) {
        	
           			 matx[i][j] = rand() % 10;
         
        	}
   		}
   		cout<<"Weight MATRIX :"<<endl;
   		for (int i = 0; i < 3; i++) {
        	for (int j = 0; j < 4; j++) {
        	
           			 cout<<matrix[i][j]<<"  ";
         
        	}
        	cout<<endl;
   		}
   		cout<<"MATRIX Xi:"<<endl;
   		for (int i = 0; i < 4; i++) {
        	for (int j = 0; j < 1; j++) {
        	
           			 cout<<matx[i][j]<<"  ";
         
        	}
        	cout<<endl;
   		}
   		pthread_t th[3];
   		
		for (int i = 0; i < 3; i++) 
		{
        		pthread_create(&th[i], NULL, multi, &i);
    		}
		
		for (int i = 0; i < 3; i++)
        		pthread_join(th[i], NULL); 
        	cout<<"Resultant MATRIX:"<<endl;
        	for (int i = 0; i < 3; i++) {
        	for (int j = 0; j < 1; j++) {
        	
           			 cout<<res[i][j]<<"  ";
         
        	}
        	cout<<endl;
   		}
   		int arr[3][1];
   		for (int i = 0; i < 3; i++) {
        	for (int j = 0; j < 1; j++) {
        	
           			 arr[i][j]=res[i][j];
         
        	}
        	
   		}
        	close(fd[0]); 
      		close(1);   
      		dup(fd[1]);  
      		write(1, arr, sizeof(arr));
		}
		else{
		
	wait(NULL);
	close(0);
      close(fd[1]); 
  
      
      dup(fd[0]); 
int arr[3][1];

     read(fd[0], arr, sizeof(arr));
     for (int i = 0; i < 3; i++) {
        	for (int j = 0; j < 1; j++) {
        	
           			 res[i][j]=arr[i][j];
         
        	}
        	
   		}
   		
   		cout<<"Resultant MATRIX in p2 after reading from pipe:"<<endl;
        	for (int i = 0; i < 3; i++) {
        	for (int j = 0; j < 1; j++) {
        	
           			 cout<<res[i][j]<<"  ";
         
        	}
        	cout<<endl;
   		}
		srand(time(0));
		for (int i = 0; i < 3; i++) {
        	for (int j = 0; j < 1; j++) {
        	
           			 matb[i][j] = rand() % 10;
         
        	}}
        	cout<<"Matrix b:"<<endl;
		for (int i = 0; i < 3; i++) {
        	for (int j = 0; j < 1; j++) {
        	
           			 cout<<matb[i][j]<<"  ";
         
        	}
        	cout<<endl;
        	}
		pthread_t th[3];
   		
		for (int i = 0; i < 3; i++) 
		{
        		pthread_create(&th[i], NULL, addi, &i);
    		}
		
		for (int i = 0; i < 3; i++)
        		pthread_join(th[i], NULL); 
        		
        	cout<<"Resultant Matrix after addition:"<<endl;
        	for (int i = 0; i < 3; i++) {
        	for (int j = 0; j < 1; j++) {
        	
           			 cout<<matadd[i][j]<<"  ";
         
        	}
        	cout<<endl;
        	}
        	
        	int arr1[3][1];
   		for (int i = 0; i < 3; i++) {
        	for (int j = 0; j < 1; j++) {
        	
           			 arr1[i][j]=matadd[i][j];
         
        	}
        	
   		}
        	close(fd1[0]); 
      		close(1);   
      		dup(fd1[1]);  
      		write(1, arr1, sizeof(arr));
	}
	}
	else
	{

	wait(NULL);
	close(0);
      close(fd1[1]); 
  
      
      dup(fd1[0]); 
int arr[3][1];

     read(fd1[0], arr, sizeof(arr));
     for (int i = 0; i < 3; i++) {
        	for (int j = 0; j < 1; j++) {
        	
           			 matadd[i][j]=arr[i][j];
         
        	}
        	
   		}
   		
   		cout<<"Addition Matrix in p3 after reading from pipe:"<<endl;
        	for (int i = 0; i < 3; i++) {
        	for (int j = 0; j < 1; j++) {
        	
           			 cout<<matadd[i][j]<<"  ";
         
        	}
        	cout<<endl;
   		}
   		pthread_t th[3];
   		for (int i = 0; i < 3; i++) 
		{
        		pthread_create(&th[i], NULL, sig, &i);
    		}
		
		for (int i = 0; i < 3; i++)
        		pthread_join(th[i], NULL); 
   		
   		cout<<"Resultant Matrix after sigmond Function:"<<endl;
        	for (int i = 0; i < 3; i++) {
        	for (int j = 0; j < 1; j++) {
        	
           			 cout<<result[i][j]<<"  ";
         
        	}
        	cout<<endl;
   		}
   		
	}
}

else{
wait(NULL);
cout<<"ending";
}
	
	
	

}

